//
//  ProfileApp.swift
//  Profile
//
//  Created by Shaima Alharbi on 12/01/1445 AH.
//

import SwiftUI

@main
struct ProfileApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
