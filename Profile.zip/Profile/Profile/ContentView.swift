//
//  ContentView.swift
//  Profile
//
//  Created by Shaima Alharbi on 12/01/1445 AH.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            NavigationView{
                List{
                    VStack(spacing: 18){
                        Image(systemName: "person")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .foregroundColor(.blue)
                            .frame(width: 100 , height: 70)
                            .contrast(70)
                            .padding(-1)
                            .padding(.top, 80)
                        Text("@ User name")
                            .fontWeight(.thin)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.trailing)
                            .padding()
                            .padding(6)
                    }
                    VStack{
                        HStack(spacing: 18){
                            Button(action:{
                            }, label:{
                                
                                Circle()
                                    .fill(Color.blue)
                                    .overlay(
                                        Image(systemName: "square.and.pencil")
                                            .font(.title2.bold())
                                            .foregroundColor(.white)
                                        )
                                    .frame(width: 50, height: 40)
                                    .shadow(color:.blue, radius: 10)
                                Text("Profile")
                                    .frame(alignment: .trailing)
                                    .foregroundColor(.blue)

                                
                            })
                              
                        
                        }
                        VStack{
                            HStack(spacing: 18){
                                Button(action:{
                                }, label:{
                                    
                                    Circle()
                                        .fill(Color.blue)
                                        .overlay(
                                            Image(systemName: "star")
                                                .font(.title2.bold())
                                                .foregroundColor(.white)
                                            )
                                        .frame(width: 50, height: 40)
                                        .shadow(color:.blue, radius: 10)
                                    Text("Favorite")
                                        .frame(alignment: .trailing)
                                        .foregroundColor(.blue)

                                    
                                })
                                  
                            }
                            VStack{
                                HStack(spacing: 18){
                                    Button(action:{
                                    }, label:{
                                        
                                        Circle()
                                            .fill(Color.blue)
                                            .overlay(
                                                Image(systemName: "book")
                                                    .font(.title2.bold())
                                                    .foregroundColor(.white)
                                                )
                                            .frame(width: 50, height: 40)
                                            .shadow(color:.blue, radius: 10)
                                        Text("Book ")
                                            .frame(alignment: .trailing)
                                            .foregroundColor(.blue)

                                        
                                    })
                                  
                                }
                                VStack{
                                    HStack(spacing: 18){
                                        Button(action:{
                                        }, label:{
                                            
                                            Circle()
                                                .fill(Color.blue)
                                                .overlay(
                                                    Image(systemName: "bookmark")
                                                        .font(.title2.bold())
                                                        .foregroundColor(.white)
                                                    )
                                                .frame(width: 50, height: 40)
                                                .shadow(color:.blue, radius: 10)
                                            Text("Save")
                                                .frame(alignment: .trailing)
                                                .foregroundColor(.blue)

                                            
                                        })
                                    }
                                 Spacer()
                                }
                            }
                            .accentColor(.primary)
                            .listRowSeparator(.hidden)
                        }
                    }
                    
                    .listStyle(.sidebar)
                    .navigationTitle("Profile")
                    .frame(alignment: .center)
                }
            }
           
            }
        }
    }
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }

